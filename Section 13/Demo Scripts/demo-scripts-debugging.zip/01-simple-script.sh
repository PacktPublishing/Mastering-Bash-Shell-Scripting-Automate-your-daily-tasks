#!/bin/bash

message="Welcome to GlobaleTraining.com"

set -x
ls -lhr > ls.output
set +x

echo $message
