#!/bin/bash
echo "Welcome to GlobaleTraining.com"

string1="Ubuntu 18.04"
string2="Bash Shell Scripting"
string3=""

echo "1:-----------------------"
echo ${#string1}

echo "2:-----------------------"
echo ${string2#Bash}
