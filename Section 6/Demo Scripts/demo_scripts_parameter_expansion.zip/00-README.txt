Shell Parameter Expansion
