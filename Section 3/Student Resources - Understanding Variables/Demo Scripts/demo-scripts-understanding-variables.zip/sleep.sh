#!/bin/bash
echo "Welcome to GlobaleTraining.com"

while true
do
 sleep 1000
done
