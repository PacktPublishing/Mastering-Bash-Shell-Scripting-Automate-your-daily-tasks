#!/bin/bash
echo "Welcome to GlobaleTraining.com"

source ./10-variables.sh

echo "COURSE: $COURSE"
echo "SITE: $SITE"

echo

gethostdetails
