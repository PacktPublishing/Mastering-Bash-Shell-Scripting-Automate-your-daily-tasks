#!/bin/bash
echo "Welcome to GlobaleTraining.com"
# $#, $?, $$, $!, $*, $@

echo "Total Arguments : $#"

echo "The status of the last command : $?"
echo "The PID of the current shell is $$"
