#!/bin/bash
echo "Welcome to GlobaleTraining.com"

course_name="Bash Shell Scripting"
echo "1: Welcome to ${course_name}"
