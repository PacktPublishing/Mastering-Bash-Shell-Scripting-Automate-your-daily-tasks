#!/bin/bash
echo "Welcome to GlobaleTraining.com"

echo "1: My home dir is - $HOME"
echo "2: My login id is - $LOGNAME"
echo "3: My shell is - $SHELL"
echo "4: My course is - $COURSE"
