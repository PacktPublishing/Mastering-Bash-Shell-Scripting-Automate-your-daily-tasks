#!/bin/bash
echo "Welcome to GlobaleTraining.com"

export course_name3="AWS VPC Mastery Course"

echo "1: Welcome to ${course_name}"
echo "2: Welcome to ${course_name2}"
echo "3: Welcome to ${course_name3}"
