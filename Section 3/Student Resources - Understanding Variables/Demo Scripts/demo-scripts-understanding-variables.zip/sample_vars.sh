name=bash
city=london
export phone_number="111-222-3333"
