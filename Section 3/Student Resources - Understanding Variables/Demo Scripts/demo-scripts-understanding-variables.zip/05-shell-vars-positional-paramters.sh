#!/bin/bash
echo "Welcome to GlobaleTraining.com"

echo "Total Argruments Passed : $#"

echo "The name of the file - $0"
