Parsing Command Line Arguments
