#!/bin/bash

echo "The title of the book is \"Linux\""

echo "The cost of the book is \$12.50"
