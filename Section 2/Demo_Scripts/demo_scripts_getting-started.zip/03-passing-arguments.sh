#!/bin/bash

NAME=$1
CITY=$2

echo "$NAME lives in $CITY!"

echo "$1 lives in $2!"
