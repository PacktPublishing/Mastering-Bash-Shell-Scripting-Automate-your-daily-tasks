#!/bin/bash

echo "1: Welcome to Bash Shell Scripting course!"
welcome_message3
welcome_message2

function welcome_message2 {
  echo "2: Welcome to Bash Shell Scripting course!"
}

welcome_message3() {
  echo "3: Welcome to Bash Shell Scripting course!"
}
