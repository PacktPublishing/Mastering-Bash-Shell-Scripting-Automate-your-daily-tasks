#!/bin/bash

# Hello World Message
echo "Hello World!"

# Welcome to the course
echo "Welcome to the Bash Shell Scripting course!"

COURSE="Bash"
COURSE="Bash Shell Scripting"

echo "I am going to complete ${COURSE} course!"
