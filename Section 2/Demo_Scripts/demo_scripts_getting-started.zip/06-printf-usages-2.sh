#!/bin/bash
#"A" "B" "C" "D" "E"

printf "%10.2f\n" 125 500.252 4556.2
