#!/bin/bash
#
#printf "1: Hello World!\n"
#printf "2a: Hello World!\n" "2b: Hello World!\n" "2c: Hello World!\n"
#printf "%s\n" "3a: Hello World!" "3b: Hello World!" "3c: Hello World!"
#printf "%sABC" "4a: Hello World!" "4b: Hello World!" "4c: Hello World!"

#printf "\n"

printf "%-10s: %5d\n" "John" 1225  "Mary"  26  "Kevin"  6  "Kelly"  26156
