#!/bin/bash

echo -n "What is your name ? "
read USER_INPUT
echo "Good Morning, ${USER_INPUT}!"
